"""
02_generate_images.py

Procedurally generates a synthetic house "photo" for every row in
housing_tabular.csv. Images are simple PIL renderings, but they are NOT
random -- key visual properties are driven by the same underlying features
that influence price (condition_score, neighborhood type, waterfront,
size), plus per-image random noise/jitter. This gives the CNN genuine
visual signal to learn from, mimicking how real listing photos correlate
with home value (paint condition, landscaping, size, water view, etc).

Visual encoding:
- condition_score (1-10) -> wall paint freshness/color saturation, lawn
  greenness, presence of clutter/cracks
- sqft_living -> house footprint width/height in the rendered image
- waterfront -> blue water band at the bottom of the image
- neighborhood -> sky color / building density (Downtown = denser, taller)
- floors -> number of stories drawn
- age (unrenovated) -> roof/wall weathering (desaturation, brown spots)

Output: data/images/house_<house_id>.jpg  (128x128 RGB)
"""

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path

np.random.seed(7)

IMG_SIZE = 128
DATA_DIR = Path(r'F:\housing_multimodal_3\data')
IMG_DIR = DATA_DIR / 'images'
IMG_DIR.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(DATA_DIR / 'housing_tabular.csv')


def clamp(v, lo=0, hi=255):
    return int(max(lo, min(hi, v)))


def make_house_image(row, rng):
    cond = row['condition_score']          # 1-10
    sqft = row['sqft_living']
    waterfront = row['waterfront']
    neighborhood = row['neighborhood']
    floors = row['floors']
    age = row['age']
    renovated = row['renovated']
    eff_age = age * (1 - 0.6 * renovated)

    # --- Sky color depends loosely on neighborhood (cosmetic variety) ---
    sky_palettes = {
        'Downtown': (180, 195, 210),
        'Suburb_North': (150, 195, 235),
        'Suburb_South': (160, 200, 230),
        'Lakeside': (140, 190, 235),
        'Rural': (170, 205, 225),
    }
    sky_base = np.array(sky_palettes.get(neighborhood, (160, 195, 225)), dtype=float)
    sky_color = tuple(clamp(c + rng.normal(0, 8)) for c in sky_base)

    img = Image.new('RGB', (IMG_SIZE, IMG_SIZE), sky_color)
    draw = ImageDraw.Draw(img)

    ground_y = 95
    # Lawn greenness scales with condition_score (healthier lawn = better kept)
    green_health = np.clip(cond / 10, 0.15, 1.0)
    lawn_color = (
        clamp(90 - 40 * green_health + rng.normal(0, 6)),
        clamp(110 + 60 * green_health + rng.normal(0, 6)),
        clamp(60 - 20 * green_health + rng.normal(0, 6)),
    )
    draw.rectangle([0, ground_y, IMG_SIZE, IMG_SIZE], fill=lawn_color)

    # Waterfront: blue band replacing part of the lawn
    if waterfront:
        water_y = ground_y + 18
        draw.rectangle([0, water_y, IMG_SIZE, IMG_SIZE],
                        fill=(clamp(60 + rng.normal(0, 5)),
                              clamp(110 + rng.normal(0, 5)),
                              clamp(190 + rng.normal(0, 5))))

    # --- House footprint size scales with sqft_living ---
    width_frac = np.clip(0.35 + (sqft - 450) / 6500 * 0.5, 0.35, 0.85)
    house_w = int(IMG_SIZE * width_frac)
    house_x0 = (IMG_SIZE - house_w) // 2
    house_x1 = house_x0 + house_w

    n_stories = max(1, round(floors))
    story_h = 22
    house_h = story_h * n_stories
    house_y1 = ground_y
    house_y0 = house_y1 - house_h

    # Downtown = denser/taller buildings nearby (background silhouettes)
    if neighborhood == 'Downtown':
        for i in range(4):
            bx0 = rng.integers(0, IMG_SIZE - 10)
            bw = rng.integers(8, 16)
            bh = rng.integers(20, 50)
            shade = clamp(120 + rng.normal(0, 15))
            draw.rectangle([bx0, ground_y - bh, bx0 + bw, ground_y],
                            fill=(shade, shade, clamp(shade + 10)))

    # --- Wall color: freshness/saturation driven by condition & age ---
    weathering = np.clip(eff_age / 80, 0, 1) * (1 - green_health * 0.3)
    base_wall_hues = [(235, 225, 200), (220, 200, 180), (200, 215, 220),
                       (230, 210, 190), (210, 220, 205)]
    wall_base = np.array(base_wall_hues[rng.integers(0, len(base_wall_hues))], dtype=float)
    # weathering desaturates and browns the wall
    wall_color = wall_base * (1 - 0.35 * weathering) + np.array([90, 75, 55]) * (0.35 * weathering)
    wall_color = tuple(clamp(c + rng.normal(0, 5)) for c in wall_color)

    draw.rectangle([house_x0, house_y0, house_x1, house_y1], fill=wall_color)

    # Per-story divider lines for multi-floor homes
    for s in range(1, n_stories):
        y = house_y1 - s * story_h
        draw.line([house_x0, y, house_x1, y], fill=tuple(clamp(c - 25) for c in wall_color), width=1)

    # --- Roof: condition affects roof color uniformity ---
    roof_color_base = (90, 55, 50) if cond > 4 else (75, 60, 55)
    roof_color = tuple(clamp(c + rng.normal(0, 10 + 15 * weathering)) for c in roof_color_base)
    roof_h = 14
    draw.polygon([
        (house_x0 - 6, house_y0),
        (house_x1 + 6, house_y0),
        ((house_x0 + house_x1) // 2, house_y0 - roof_h)
    ], fill=roof_color)

    # --- Windows: regular grid, condition affects "cleanliness" (brightness/jitter) ---
    win_color_base = (150, 200, 225) if cond > 5 else (130, 160, 170)
    n_win_cols = max(1, house_w // 18)
    for s in range(n_stories):
        wy0 = house_y1 - (s + 1) * story_h + 5
        wy1 = wy0 + 10
        for c in range(n_win_cols):
            wx0 = house_x0 + 6 + c * (house_w // n_win_cols)
            wx1 = wx0 + 8
            jitter = rng.normal(0, 8) * (1 + weathering)  # messier windows if run-down
            wc = tuple(clamp(ch + jitter) for ch in win_color_base)
            if wx1 < house_x1 - 2:
                draw.rectangle([wx0, wy0, wx1, wy1], fill=wc, outline=(70, 60, 50))

    # Door
    door_w, door_h = 10, 18
    door_x0 = (house_x0 + house_x1) // 2 - door_w // 2
    draw.rectangle([door_x0, house_y1 - door_h, door_x0 + door_w, house_y1],
                    fill=(70, 45, 35) if cond > 4 else (60, 50, 45))

    # Garage (if present) widens footprint slightly -- represented by a side block
    if row['garage_spaces'] > 0:
        gw = 16 + 6 * min(row['garage_spaces'], 3)
        gx0 = house_x1
        gx1 = min(IMG_SIZE - 2, gx0 + gw)
        draw.rectangle([gx0, house_y1 - 16, gx1, house_y1], fill=tuple(clamp(c - 15) for c in wall_color))

    # Cracks / disrepair marks for low-condition homes
    if cond < 4:
        n_marks = int((4 - cond) * 3)
        for _ in range(n_marks):
            mx = rng.integers(house_x0, house_x1)
            my = rng.integers(house_y0, house_y1)
            ml = rng.integers(3, 9)
            draw.line([mx, my, mx + rng.integers(-3, 3), my + ml],
                      fill=(60, 50, 40), width=1)

    # Trees: more/healthier for well-kept properties (cosmetic correlation)
    n_trees = int(np.clip(1 + green_health * 3 + rng.normal(0, 0.5), 0, 5))
    for _ in range(n_trees):
        tx = rng.integers(2, IMG_SIZE - 8) if rng.random() < 0.5 else rng.integers(2, IMG_SIZE - 8)
        # keep trees away from directly overlapping the house door area but allow beside house
        ty = ground_y
        trunk_h = rng.integers(6, 12)
        draw.line([tx, ty, tx, ty - trunk_h], fill=(80, 55, 40), width=2)
        leaf_r = rng.integers(5, 9)
        leaf_color = (clamp(40 + rng.normal(0, 10)), clamp(110 + 50 * green_health + rng.normal(0, 10)), clamp(40))
        draw.ellipse([tx - leaf_r, ty - trunk_h - leaf_r, tx + leaf_r, ty - trunk_h + leaf_r], fill=leaf_color)

    # Slight blur for photographic softness + mild jpeg-like noise
    img = img.filter(ImageFilter.GaussianBlur(radius=0.4))
    arr = np.array(img).astype(np.int16)
    arr += rng.normal(0, 4, arr.shape).astype(np.int16)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    img = Image.fromarray(arr)

    return img


for idx, row in df.iterrows():
    rng = np.random.default_rng(1000 + idx)
    img = make_house_image(row, rng)
    img.save(IMG_DIR / f"house_{row['house_id']}.jpg", quality=90)

n_files = len(list(IMG_DIR.glob('*.jpg')))
print(f'Generated {n_files} images in {IMG_DIR}')
