"""
01_generate_tabular_data.py

Generates a realistic synthetic housing sales dataset.

NOTE ON DATA SOURCE:
This project ships with a synthetic dataset generator so the full pipeline
runs end-to-end without external downloads (no internet access to dataset
hosts like Kaggle is available in this environment). The generator encodes
realistic real-estate pricing relationships (location premium, size, quality,
age depreciation, amenities) with noise, so the regression problem is
non-trivial but learnable -- exactly like a real housing dataset such as
the Kaggle "House Sales in King County" dataset.

TO USE REAL DATA INSTEAD:
Replace this script's output (data/housing_tabular.csv) with your real
dataset, keeping a `house_id` column that matches image filenames
(images/house_<house_id>.jpg). Update FEATURE COLUMNS in 02 if your
schema differs.
"""

import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)

N = 1200  # number of houses

# ---- Core structural features ----
sqft_living = np.random.normal(2000, 700, N).clip(450, 6500)
bedrooms = np.clip(np.round(sqft_living / 550 + np.random.normal(0, 0.8, N)), 1, 8).astype(int)
bathrooms = np.clip(np.round(bedrooms * 0.75 + np.random.normal(0, 0.6, N), 1), 1, 6)
lot_size = (sqft_living * np.random.uniform(1.2, 4.5, N) + np.random.normal(0, 500, N)).clip(800, 40000)
floors = np.random.choice([1, 1.5, 2, 2.5, 3], N, p=[0.35, 0.1, 0.35, 0.1, 0.1])
age = np.random.exponential(20, N).clip(0, 110).astype(int)
garage = np.random.choice([0, 1, 2, 3], N, p=[0.15, 0.35, 0.4, 0.1])

# ---- Quality / condition (this is what the "image" will visually encode) ----
# condition_score: overall upkeep/finish quality, 1 (poor) - 10 (excellent)
condition_score = np.clip(np.random.normal(6.5, 1.8, N), 1, 10)
# renovated reduces effective age
renovated = np.random.binomial(1, 0.25, N)
effective_age = age * (1 - 0.6 * renovated)

# ---- Location ----
neighborhoods = ['Downtown', 'Suburb_North', 'Suburb_South', 'Lakeside', 'Rural']
neighborhood_premium = {'Downtown': 1.35, 'Suburb_North': 1.05, 'Suburb_South': 0.95,
                         'Lakeside': 1.5, 'Rural': 0.7}
neighborhood = np.random.choice(neighborhoods, N, p=[0.2, 0.25, 0.25, 0.15, 0.15])
neighborhood_mult = np.array([neighborhood_premium[n] for n in neighborhood])

waterfront = np.where(neighborhood == 'Lakeside',
                       np.random.binomial(1, 0.4, N),
                       np.random.binomial(1, 0.02, N))

school_rating = np.clip(np.random.normal(6.5, 1.5, N) +
                         (neighborhood_mult - 1) * 3, 1, 10)

# ---- Price model (ground truth generative process) ----
base_price = (
    sqft_living * 145
    + bedrooms * 4000
    + bathrooms * 7000
    + lot_size * 1.8
    + garage * 6000
    + (condition_score - 5) * 9000
    + waterfront * 120000
    + (school_rating - 5) * 8000
    - effective_age * 900
)

price = base_price * neighborhood_mult
price = price * np.random.normal(1.0, 0.08, N)  # noise
price = price.clip(60000, None)

df = pd.DataFrame({
    'house_id': [f'{i:04d}' for i in range(N)],
    'sqft_living': sqft_living.round(0).astype(int),
    'bedrooms': bedrooms,
    'bathrooms': bathrooms,
    'lot_size': lot_size.round(0).astype(int),
    'floors': floors,
    'age': age,
    'renovated': renovated,
    'garage_spaces': garage,
    'waterfront': waterfront,
    'school_rating': school_rating.round(1),
    'neighborhood': neighborhood,
    'condition_score': condition_score.round(1),  # drives the *visual* quality of the image
    'price': price.round(0).astype(int),
})

out_dir = Path('/home/claude/housing_multimodal/data')
out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out_dir / 'housing_tabular.csv', index=False)

print(df.shape)
print(df.head())
print('\nPrice stats:')
print(df['price'].describe())
