"""
04_baseline_comparisons.py

Trains two ablation baselines using the SAME train/val/test split, scaler,
and target standardization as the multimodal model, so results are
directly comparable:

  A) Tabular-only  : TabularMLP -> regression head  (no image branch)
  B) Image-only     : ImageCNN   -> regression head  (no tabular branch)

Then compares MAE / RMSE / R2 against the multimodal fusion model to show
the value added by combining modalities.
"""

import json
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)

BASE = Path(r'F:\housing_multimodal_3')
DATA = BASE / 'data'
OUT = BASE / 'outputs'
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# ---- Recreate identical split / preprocessing as 03_multimodal_pipeline.py ----
df = pd.read_csv(DATA / 'housing_tabular.csv')
NUMERIC_COLS = ['sqft_living', 'bedrooms', 'bathrooms', 'lot_size', 'floors',
                 'age', 'garage_spaces', 'school_rating', 'condition_score']
BINARY_COLS = ['renovated', 'waterfront']
CATEGORICAL_COLS = ['neighborhood']

df = pd.get_dummies(df, columns=CATEGORICAL_COLS, prefix='nbhd')
ONEHOT_COLS = [c for c in df.columns if c.startswith('nbhd_')]
FEATURE_COLS = NUMERIC_COLS + BINARY_COLS + ONEHOT_COLS
df['log_price'] = np.log1p(df['price'])

train_df, temp_df = train_test_split(df, test_size=0.30, random_state=SEED)
val_df, test_df = train_test_split(temp_df, test_size=0.50, random_state=SEED)

scaler = StandardScaler()
scaler.fit(train_df[FEATURE_COLS].values)

TARGET_MEAN = train_df['log_price'].mean()
TARGET_STD = train_df['log_price'].std()
for split_df in (train_df, val_df, test_df):
    split_df['log_price_std'] = (split_df['log_price'] - TARGET_MEAN) / TARGET_STD

IMG_TRANSFORM_TRAIN = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
])
IMG_TRANSFORM_EVAL = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
])


class HousingMultimodalDataset(Dataset):
    def __init__(self, dataframe, feature_cols, scaler, img_dir, transform):
        self.df = dataframe.reset_index(drop=True)
        self.feature_cols = feature_cols
        self.scaler = scaler
        self.img_dir = Path(img_dir)
        self.transform = transform
        self.X_tab = self.scaler.transform(self.df[feature_cols].values).astype(np.float32)
        self.y = self.df['log_price_std'].values.astype(np.float32)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img_path = self.img_dir / f"house_{row['house_id']}.jpg"
        img = Image.open(img_path).convert('RGB')
        img = self.transform(img)
        tab = torch.tensor(self.X_tab[idx])
        target = torch.tensor(self.y[idx])
        return img, tab, target


BATCH_SIZE = 32
train_ds = HousingMultimodalDataset(train_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_TRAIN)
val_ds = HousingMultimodalDataset(val_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_EVAL)
test_ds = HousingMultimodalDataset(test_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_EVAL)
train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False)
test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False)


# ---- Reusable branch modules (identical architecture to multimodal model) ----
class ImageCNN(nn.Module):
    def __init__(self, out_dim=64):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.AdaptiveAvgPool2d(1),
        )
        self.proj = nn.Sequential(nn.Flatten(), nn.Linear(128, out_dim), nn.ReLU(), nn.Dropout(0.3))

    def forward(self, x):
        return self.proj(self.features(x))


class TabularMLP(nn.Module):
    def __init__(self, in_dim, out_dim=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 64), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(64, out_dim), nn.ReLU(),
        )

    def forward(self, x):
        return self.net(x)


class TabularOnlyModel(nn.Module):
    def __init__(self, n_tab_features):
        super().__init__()
        self.tabular_branch = TabularMLP(n_tab_features, out_dim=32)
        self.head = nn.Sequential(nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, 1))

    def forward(self, img, tab):
        return self.head(self.tabular_branch(tab)).squeeze(1)


class ImageOnlyModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.image_branch = ImageCNN(out_dim=64)
        self.head = nn.Sequential(nn.Linear(64, 16), nn.ReLU(), nn.Linear(16, 1))

    def forward(self, img, tab):
        return self.head(self.image_branch(img)).squeeze(1)


def evaluate(model, loader):
    model.eval()
    preds, targets = [], []
    with torch.no_grad():
        for img, tab, y in loader:
            img, tab, y = img.to(DEVICE), tab.to(DEVICE), y.to(DEVICE)
            out = model(img, tab)
            preds.append(out.cpu().numpy())
            targets.append(y.cpu().numpy())
    preds = np.concatenate(preds) * TARGET_STD + TARGET_MEAN
    targets = np.concatenate(targets) * TARGET_STD + TARGET_MEAN
    preds = np.expm1(preds)
    targets = np.expm1(targets)
    mae = mean_absolute_error(targets, preds)
    rmse = np.sqrt(mean_squared_error(targets, preds))
    r2 = r2_score(targets, preds)
    return mae, rmse, r2, preds, targets


def train_model(model, name, epochs=60, patience=10, lr=5e-4):
    print(f'\n--- Training {name} ---')
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=4)
    best_val_mae = float('inf')
    best_state = None
    patience_counter = 0

    for epoch in range(1, epochs + 1):
        model.train()
        for img, tab, y in train_loader:
            img, tab, y = img.to(DEVICE), tab.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            out = model(img, tab)
            loss = criterion(out, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        val_mae, val_rmse, val_r2, _, _ = evaluate(model, val_loader)
        # need val_loss for scheduler; recompute quickly via criterion on standardized scale
        model.eval()
        with torch.no_grad():
            val_loss_total, n = 0.0, 0
            for img, tab, y in val_loader:
                img, tab, y = img.to(DEVICE), tab.to(DEVICE), y.to(DEVICE)
                out = model(img, tab)
                val_loss_total += criterion(out, y).item() * img.size(0)
                n += img.size(0)
            val_loss = val_loss_total / n
        scheduler.step(val_loss)

        improved = val_mae < best_val_mae
        if improved:
            best_val_mae = val_mae
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1

        if epoch == 1 or epoch % 10 == 0 or improved:
            flag = ' *' if improved else ''
            print(f'  Epoch {epoch:3d}/{epochs} | val_MAE ${val_mae:,.0f} | val_RMSE ${val_rmse:,.0f} | val_R2 {val_r2:.3f}{flag}')

        if patience_counter >= patience:
            print(f'  Early stopping at epoch {epoch}')
            break

    model.load_state_dict(best_state)
    return model


# ---- Train tabular-only ----
tab_model = TabularOnlyModel(n_tab_features=len(FEATURE_COLS)).to(DEVICE)
tab_model = train_model(tab_model, 'Tabular-Only MLP')
tab_mae, tab_rmse, tab_r2, _, _ = evaluate(tab_model, test_loader)
print(f'\n[Tabular-Only]  Test MAE=${tab_mae:,.0f}  RMSE=${tab_rmse:,.0f}  R2={tab_r2:.4f}')

# ---- Train image-only ----
img_model = ImageOnlyModel().to(DEVICE)
img_model = train_model(img_model, 'Image-Only CNN')
img_mae, img_rmse, img_r2, _, _ = evaluate(img_model, test_loader)
print(f'\n[Image-Only]    Test MAE=${img_mae:,.0f}  RMSE=${img_rmse:,.0f}  R2={img_r2:.4f}')

# ---- Load multimodal metrics already computed ----
with open(OUT / 'metrics_multimodal.json') as f:
    mm = json.load(f)
print(f'\n[Multimodal]    Test MAE=${mm["test_MAE"]:,.0f}  RMSE=${mm["test_RMSE"]:,.0f}  R2={mm["test_R2"]:.4f}')

# ---- Comparison table + bar chart ----
results = pd.DataFrame([
    {'Model': 'Image-Only (CNN)', 'MAE': img_mae, 'RMSE': img_rmse, 'R2': img_r2},
    {'Model': 'Tabular-Only (MLP)', 'MAE': tab_mae, 'RMSE': tab_rmse, 'R2': tab_r2},
    {'Model': 'Multimodal (Fusion)', 'MAE': mm['test_MAE'], 'RMSE': mm['test_RMSE'], 'R2': mm['test_R2']},
])
results.to_csv(OUT / 'model_comparison.csv', index=False)
print('\n' + results.to_string(index=False))

fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
for ax, metric, title in zip(axes, ['MAE', 'RMSE', 'R2'],
                              ['Mean Absolute Error ($)', 'Root Mean Squared Error ($)', 'R² Score']):
    colors = ['#888888', '#4C72B0', '#55A868']
    bars = ax.bar(results['Model'], results[metric], color=colors)
    ax.set_title(title)
    ax.tick_params(axis='x', rotation=20)
    for bar, val in zip(bars, results[metric]):
        label = f'{val:,.0f}' if metric != 'R2' else f'{val:.3f}'
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height(), label,
                ha='center', va='bottom', fontsize=9)
plt.tight_layout()
plt.savefig(OUT / 'model_comparison.png', dpi=130)
plt.close()

print('\nSaved: model_comparison.csv, model_comparison.png')
