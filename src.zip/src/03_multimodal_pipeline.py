"""
03_multimodal_pipeline.py

Full multimodal pipeline:
  1. Load + split tabular & image data
  2. Preprocess tabular features (scale numeric, one-hot categorical)
  3. PyTorch Dataset that returns (image_tensor, tabular_tensor, price)
  4. CNN branch  -> image embedding
     MLP branch  -> tabular embedding
     Fusion head -> concat embeddings -> price prediction
  5. Train with early stopping on validation MAE
  6. Evaluate on held-out test set: MAE, RMSE, R^2
  7. Save model, scaler, plots, and metrics report

Run: python3 03_multimodal_pipeline.py
"""

import json
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)
BASE = Path(r'F:\housing_multimodal_3')
DATA = BASE / 'data'
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print('Using device:', DEVICE)

# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
df = pd.read_csv(DATA / 'housing_tabular.csv')

NUMERIC_COLS = ['sqft_living', 'bedrooms', 'bathrooms', 'lot_size', 'floors',
                 'age', 'garage_spaces', 'school_rating', 'condition_score']
BINARY_COLS = ['renovated', 'waterfront']
CATEGORICAL_COLS = ['neighborhood']
TARGET_COL = 'price'

df = pd.get_dummies(df, columns=CATEGORICAL_COLS, prefix='nbhd')
ONEHOT_COLS = [c for c in df.columns if c.startswith('nbhd_')]
FEATURE_COLS = NUMERIC_COLS + BINARY_COLS + ONEHOT_COLS

print(f'Tabular feature columns ({len(FEATURE_COLS)}):', FEATURE_COLS)

# Log-transform the target -- housing prices are right-skewed; predicting
# log(price) stabilizes training and is standard practice for this task.
df['log_price'] = np.log1p(df[TARGET_COL])

# ----------------------------------------------------------------------
# 2. Train / val / test split (70 / 15 / 15)
# ----------------------------------------------------------------------
train_df, temp_df = train_test_split(df, test_size=0.30, random_state=SEED)
val_df, test_df = train_test_split(temp_df, test_size=0.50, random_state=SEED)
print(f'Train: {len(train_df)}  Val: {len(val_df)}  Test: {len(test_df)}')

# Fit scaler on TRAIN ONLY to avoid leakage
scaler = StandardScaler()
scaler.fit(train_df[FEATURE_COLS].values)

# Standardize the (already log-transformed) target too. log_price values
# sit around ~12.8 with the network's final layer initialized near 0, so
# training directly on raw log_price causes a huge initial loss spike and
# unstable optimization. Standardizing keeps the regression target in a
# well-behaved range; we invert (de-standardize -> expm1) at eval time.
TARGET_MEAN = train_df['log_price'].mean()
TARGET_STD = train_df['log_price'].std()
print(f'Target log_price standardization: mean={TARGET_MEAN:.4f}, std={TARGET_STD:.4f}')

for split_df in (train_df, val_df, test_df):
    split_df['log_price_std'] = (split_df['log_price'] - TARGET_MEAN) / TARGET_STD

# ----------------------------------------------------------------------
# 3. Dataset
# ----------------------------------------------------------------------
IMG_TRANSFORM_TRAIN = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
])
IMG_TRANSFORM_EVAL = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]),
])


class HousingMultimodalDataset(Dataset):
    def __init__(self, dataframe, feature_cols, scaler, img_dir, transform):
        self.df = dataframe.reset_index(drop=True)
        self.feature_cols = feature_cols
        self.scaler = scaler
        self.img_dir = Path(img_dir)
        self.transform = transform
        self.X_tab = self.scaler.transform(self.df[feature_cols].values).astype(np.float32)
        self.y = self.df['log_price_std'].values.astype(np.float32)
        self.price_raw = self.df['price'].values.astype(np.float32)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img_path = self.img_dir / f"house_{row['house_id']}.jpg"
        img = Image.open(img_path).convert('RGB')
        img = self.transform(img)
        tab = torch.tensor(self.X_tab[idx])
        target = torch.tensor(self.y[idx])
        return img, tab, target


train_ds = HousingMultimodalDataset(train_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_TRAIN)
val_ds = HousingMultimodalDataset(val_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_EVAL)
test_ds = HousingMultimodalDataset(test_df, FEATURE_COLS, scaler, DATA / 'images', IMG_TRANSFORM_EVAL)

BATCH_SIZE = 32
train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)


# ----------------------------------------------------------------------
# 4. Model: CNN image branch + MLP tabular branch + fusion head
# ----------------------------------------------------------------------
class ImageCNN(nn.Module):
    """Small CNN feature extractor for 64x64 house photos."""
    def __init__(self, out_dim=64):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(), nn.MaxPool2d(2),   # 64->32
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),  # 32->16
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),  # 16->8
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(), nn.AdaptiveAvgPool2d(1),  # 8->1
        )
        self.proj = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128, out_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
        )

    def forward(self, x):
        x = self.features(x)
        return self.proj(x)


class TabularMLP(nn.Module):
    """MLP feature extractor for tabular features."""
    def __init__(self, in_dim, out_dim=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 64), nn.ReLU(), nn.Dropout(0.2),
            nn.Linear(64, out_dim), nn.ReLU(),
        )

    def forward(self, x):
        return self.net(x)


class FusionModel(nn.Module):
    """Concatenates CNN image embedding + tabular embedding, regresses log(price)."""
    def __init__(self, n_tab_features, img_emb_dim=64, tab_emb_dim=32):
        super().__init__()
        self.image_branch = ImageCNN(out_dim=img_emb_dim)
        self.tabular_branch = TabularMLP(n_tab_features, out_dim=tab_emb_dim)
        fused_dim = img_emb_dim + tab_emb_dim
        self.head = nn.Sequential(
            nn.Linear(fused_dim, 64), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(64, 16), nn.ReLU(),
            nn.Linear(16, 1),
        )

    def forward(self, img, tab):
        img_emb = self.image_branch(img)
        tab_emb = self.tabular_branch(tab)
        fused = torch.cat([img_emb, tab_emb], dim=1)
        out = self.head(fused)
        return out.squeeze(1)


model = FusionModel(n_tab_features=len(FEATURE_COLS)).to(DEVICE)
n_params = sum(p.numel() for p in model.parameters())
print(f'Model parameters: {n_params:,}')

# ----------------------------------------------------------------------
# 5. Training loop with early stopping (on val MAE in $ space)
# ----------------------------------------------------------------------
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=5e-4, weight_decay=1e-5)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=4)

EPOCHS = 60
PATIENCE = 10

history = {'train_loss': [], 'val_loss': [], 'val_mae': []}
best_val_mae = float('inf')
best_state = None
patience_counter = 0


def evaluate(loader):
    model.eval()
    preds, targets = [], []
    total_loss = 0.0
    with torch.no_grad():
        for img, tab, y in loader:
            img, tab, y = img.to(DEVICE), tab.to(DEVICE), y.to(DEVICE)
            out = model(img, tab)
            loss = criterion(out, y)
            total_loss += loss.item() * img.size(0)
            preds.append(out.cpu().numpy())
            targets.append(y.cpu().numpy())
    preds = np.concatenate(preds) * TARGET_STD + TARGET_MEAN   # undo standardization
    targets = np.concatenate(targets) * TARGET_STD + TARGET_MEAN
    preds = np.expm1(preds)      # back to $ space
    targets = np.expm1(targets)
    mae = mean_absolute_error(targets, preds)
    rmse = np.sqrt(mean_squared_error(targets, preds))
    r2 = r2_score(targets, preds)
    avg_loss = total_loss / len(loader.dataset)
    return avg_loss, mae, rmse, r2, preds, targets


print('\n--- Training ---')
for epoch in range(1, EPOCHS + 1):
    model.train()
    running_loss = 0.0
    for img, tab, y in train_loader:
        img, tab, y = img.to(DEVICE), tab.to(DEVICE), y.to(DEVICE)
        optimizer.zero_grad()
        out = model(img, tab)
        loss = criterion(out, y)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        optimizer.step()
        running_loss += loss.item() * img.size(0)
    train_loss = running_loss / len(train_ds)

    val_loss, val_mae, val_rmse, val_r2, _, _ = evaluate(val_loader)
    scheduler.step(val_loss)

    history['train_loss'].append(train_loss)
    history['val_loss'].append(val_loss)
    history['val_mae'].append(val_mae)

    improved = val_mae < best_val_mae
    if improved:
        best_val_mae = val_mae
        best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        patience_counter = 0
    else:
        patience_counter += 1

    if epoch == 1 or epoch % 5 == 0 or improved:
        flag = ' *' if improved else ''
        print(f'Epoch {epoch:3d}/{EPOCHS} | train_loss(log) {train_loss:.4f} | '
              f'val_loss(log) {val_loss:.4f} | val_MAE ${val_mae:,.0f} | '
              f'val_RMSE ${val_rmse:,.0f} | val_R2 {val_r2:.3f}{flag}')

    if patience_counter >= PATIENCE:
        print(f'Early stopping at epoch {epoch} (no val_MAE improvement for {PATIENCE} epochs)')
        break

# Restore best model
model.load_state_dict(best_state)

# ----------------------------------------------------------------------
# 6. Final evaluation on TEST set
# ----------------------------------------------------------------------
print('\n--- Final Test Evaluation (multimodal model) ---')
test_loss, test_mae, test_rmse, test_r2, test_preds, test_targets = evaluate(test_loader)
print(f'Test MAE:  ${test_mae:,.2f}')
print(f'Test RMSE: ${test_rmse:,.2f}')
print(f'Test R2:   {test_r2:.4f}')

mean_price_test = test_targets.mean()
print(f'Test MAE as % of mean price: {100*test_mae/mean_price_test:.2f}%')

torch.save(model.state_dict(), OUT / 'fusion_model.pt')

# ----------------------------------------------------------------------
# 7. Save artifacts: training curves, predictions plot, metrics json
# ----------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
axes[0].plot(history['train_loss'], label='Train Loss (log-space MSE)')
axes[0].plot(history['val_loss'], label='Val Loss (log-space MSE)')
axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss'); axes[0].legend(); axes[0].set_title('Training Curve')

axes[1].scatter(test_targets, test_preds, alpha=0.5, s=18)
lims = [min(test_targets.min(), test_preds.min()), max(test_targets.max(), test_preds.max())]
axes[1].plot(lims, lims, 'r--', linewidth=1)
axes[1].set_xlabel('Actual Price ($)'); axes[1].set_ylabel('Predicted Price ($)')
axes[1].set_title(f'Test Predictions (Multimodal)\nMAE=${test_mae:,.0f}  RMSE=${test_rmse:,.0f}  R2={test_r2:.3f}')
plt.tight_layout()
plt.savefig(OUT / 'training_and_predictions.png', dpi=130)
plt.close()

metrics = {
    'model': 'multimodal_cnn_tabular_fusion',
    'n_train': len(train_ds), 'n_val': len(val_ds), 'n_test': len(test_ds),
    'n_params': n_params,
    'epochs_trained': len(history['train_loss']),
    'test_MAE': float(test_mae),
    'test_RMSE': float(test_rmse),
    'test_R2': float(test_r2),
    'test_MAE_pct_of_mean_price': float(100 * test_mae / mean_price_test),
}
with open(OUT / 'metrics_multimodal.json', 'w') as f:
    json.dump(metrics, f, indent=2)

# Save feature columns + scaler params for reproducibility / inference script
np.save(OUT / 'scaler_mean.npy', scaler.mean_)
np.save(OUT / 'scaler_scale.npy', scaler.scale_)
with open(OUT / 'feature_cols.json', 'w') as f:
    json.dump(FEATURE_COLS, f)

print('\nSaved: fusion_model.pt, training_and_predictions.png, metrics_multimodal.json')
